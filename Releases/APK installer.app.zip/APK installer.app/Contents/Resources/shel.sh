echo `"$2" install -r "$1"` > /tmp/apk_installer_log.txt
